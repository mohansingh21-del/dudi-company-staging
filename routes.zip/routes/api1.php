<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Controllers
|--------------------------------------------------------------------------
*/

use App\Http\Controllers\Api\AuthController;

use App\Http\Controllers\Api\Admin\EmployeeController;
use App\Http\Controllers\Api\Admin\DepartmentsController;
use App\Http\Controllers\Api\Admin\BranchController;

use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\Admin\AttendanceController as AdminAttendanceController;

use App\Http\Controllers\Api\StateController;
use App\Http\Controllers\Api\CityController;

/*
|--------------------------------------------------------------------------
| NEW Mining Workforce Controllers
|--------------------------------------------------------------------------
*/

use App\Http\Controllers\Api\Admin\ShiftController;
use App\Http\Controllers\Api\Admin\SiteController;
use App\Http\Controllers\Api\Admin\DesignationController;
use App\Http\Controllers\Api\Admin\LeaveController;
use App\Http\Controllers\Api\Admin\LeaveTypeController;
use App\Http\Controllers\Api\Admin\PayrollController;
use App\Http\Controllers\Api\Admin\ReportController;
use App\Http\Controllers\Api\Admin\AttendanceUploadController;
use App\Http\Controllers\Api\Admin\EmployeeShiftAssignmentController;

/*
|--------------------------------------------------------------------------
| Existing Vehicle Controllers
|--------------------------------------------------------------------------
*/

use App\Http\Controllers\Api\Admin\VehicleManufacturerController;
use App\Http\Controllers\Api\Admin\VehicleTypeController;
use App\Http\Controllers\Api\Admin\VehicleModelController;
use App\Http\Controllers\Api\Admin\VehicleController;
use App\Http\Controllers\Api\Admin\VehicleInvoiceController;
use App\Http\Controllers\Api\Admin\VehicleAmcController;
use App\Http\Controllers\Api\Admin\VehiclePermitController;
use App\Http\Controllers\Api\Admin\VehicleInsuranceController;
use App\Http\Controllers\Api\Admin\VehiclePuccController;
use App\Http\Controllers\Api\Admin\VehicleFitnessController;
use App\Http\Controllers\Api\Admin\VehicleDocumentController;
use App\Http\Controllers\Api\Admin\FuelEntryController;
use App\Http\Controllers\Api\Admin\VehicleDriverMappingController;
use App\Http\Controllers\Api\Admin\VehicleMaintenanceController;
use App\Http\Controllers\Api\Admin\ServiceTypeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    */

    Route::prefix('auth')->group(function () {

        Route::post('login', [AuthController::class, 'login']);

        Route::post('send-otp', [AuthController::class, 'sendOtp']);

        Route::post('verify-otp', [AuthController::class, 'verifyOtp']);

        Route::post('resend-otp', [AuthController::class, 'resendOtp']);
    });

    /*
    |--------------------------------------------------------------------------
    | Public APIs
    |--------------------------------------------------------------------------
    */

    Route::get('/states', [StateController::class, 'getStates']);

    Route::get('/states/{id}/cities', [CityController::class, 'getCities']);

    /*
    |--------------------------------------------------------------------------
    | Employee Attendance APIs
    |--------------------------------------------------------------------------
    */

    Route::middleware(['auth:sanctum'])
        ->prefix('attendance')
        ->group(function () {

            Route::post('mark-in', [AttendanceController::class, 'markAttendance']);

            Route::post('mark-out', [AttendanceController::class, 'markOutAttendance']);

            Route::post('history', [AttendanceController::class, 'getAttendance']);

            Route::post('status', [AttendanceController::class, 'checkStatus']);

            Route::post('correction', [AttendanceController::class, 'requestCorrection']);
        });

    /*
    |--------------------------------------------------------------------------
    | ADMIN APIs
    |--------------------------------------------------------------------------
    */

    Route::middleware(['auth:sanctum', 'role:super-admin'])
        ->prefix('admin')
        ->group(function () {

            /*
            |--------------------------------------------------------------------------
            | Departments
            |--------------------------------------------------------------------------
            */

            Route::prefix('departments')->group(function () {

                Route::get('/', [DepartmentsController::class, 'index']);

                Route::get('{id}', [DepartmentsController::class, 'show']);

                Route::post('/', [DepartmentsController::class, 'store']);

                Route::patch('{id}/status', [DepartmentsController::class, 'toggleStatus']);

                Route::delete('{id}', [DepartmentsController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Sites
            |--------------------------------------------------------------------------
            */

            Route::prefix('sites')->group(function () {

                Route::get('/', [SiteController::class, 'index']);

                Route::get('{id}', [SiteController::class, 'show']);

                Route::post('/', [SiteController::class, 'store']);

                Route::put('{id}', [SiteController::class, 'update']);

                Route::patch('{id}/status', [SiteController::class, 'toggleStatus']);

                Route::delete('{id}', [SiteController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Designations
            |--------------------------------------------------------------------------
            */

            Route::prefix('designations')->group(function () {

                Route::get('/', [DesignationController::class, 'index']);

                Route::get('{id}', [DesignationController::class, 'show']);

                Route::post('/', [DesignationController::class, 'store']);

                Route::put('{id}', [DesignationController::class, 'update']);

                Route::patch('{id}/status', [DesignationController::class, 'toggleStatus']);

                Route::delete('{id}', [DesignationController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Shifts
            |--------------------------------------------------------------------------
            */

            Route::prefix('shifts')->group(function () {

                Route::get('/', [ShiftController::class, 'index']);

                Route::get('{id}', [ShiftController::class, 'show']);

                Route::post('/', [ShiftController::class, 'store']);

                Route::put('{id}', [ShiftController::class, 'update']);

                Route::patch('{id}/status', [ShiftController::class, 'toggleStatus']);

                Route::delete('{id}', [ShiftController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Employees
            |--------------------------------------------------------------------------
            */

            Route::prefix('employees')->group(function () {

                Route::get('/', [EmployeeController::class, 'index']);

                Route::get('{id}', [EmployeeController::class, 'show']);

                Route::post('/', [EmployeeController::class, 'store']);

                Route::put('{id}', [EmployeeController::class, 'update']);

                Route::post('bulk-upload', [EmployeeController::class, 'bulkUpload']);

                Route::patch('{id}/status', [EmployeeController::class, 'toggleStatus']);

                Route::delete('{id}', [EmployeeController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Employee Shift Assignment
            |--------------------------------------------------------------------------
            */

            Route::prefix('shift-assignments')->group(function () {

                Route::get('/', [EmployeeShiftAssignmentController::class, 'index']);

                Route::post('/', [EmployeeShiftAssignmentController::class, 'store']);

                Route::put('{id}', [EmployeeShiftAssignmentController::class, 'update']);

                Route::delete('{id}', [EmployeeShiftAssignmentController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Attendance Upload
            |--------------------------------------------------------------------------
            */

            Route::prefix('attendance')->group(function () {

                Route::post(
                    'upload',
                    [AttendanceUploadController::class, 'upload']
                );

                Route::get(
                    'report',
                    [AdminAttendanceController::class, 'getAttendanceReport']
                );

                Route::get(
                    'details',
                    [AdminAttendanceController::class, 'getEmployeeDetails']
                );
            });

            /*
            |--------------------------------------------------------------------------
            | Leave Types
            |--------------------------------------------------------------------------
            */

            Route::apiResource('leave-types', LeaveTypeController::class);

            /*
            |--------------------------------------------------------------------------
            | Leaves
            |--------------------------------------------------------------------------
            */

            Route::prefix('leaves')->group(function () {

                Route::get('/', [LeaveController::class, 'index']);

                Route::post('/', [LeaveController::class, 'store']);

                Route::get('{id}', [LeaveController::class, 'show']);

                Route::put('{id}', [LeaveController::class, 'update']);

                Route::post('{id}/approve', [LeaveController::class, 'approve']);

                Route::post('{id}/reject', [LeaveController::class, 'reject']);

                Route::delete('{id}', [LeaveController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Payroll
            |--------------------------------------------------------------------------
            */

            Route::prefix('payroll')->group(function () {

                Route::get('/', [PayrollController::class, 'index']);

                Route::post('generate', [PayrollController::class, 'generate']);

                Route::get('{id}', [PayrollController::class, 'show']);

                Route::get('salary-slip/{id}', [PayrollController::class, 'salarySlip']);

                Route::delete('{id}', [PayrollController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Reports
            |--------------------------------------------------------------------------
            */

            Route::prefix('reports')->group(function () {

                Route::get('attendance', [ReportController::class, 'attendance']);

                Route::get('payroll', [ReportController::class, 'payroll']);

                Route::get('leave', [ReportController::class, 'leave']);

                Route::get('employees', [ReportController::class, 'employees']);
            });

            /*
            |--------------------------------------------------------------------------
            | Existing Vehicle Management Routes
            |--------------------------------------------------------------------------
            */

            // KEEP YOUR EXISTING VEHICLE ROUTES HERE
            // NO CHANGES REQUIRED
        });
});
