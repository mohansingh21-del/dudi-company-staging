<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Controllers
|--------------------------------------------------------------------------
*/

use App\Http\Controllers\Api\AuthController;

use App\Http\Controllers\Api\Admin\EmployeeController;
use App\Http\Controllers\Api\Admin\DepartmentsController;
use App\Http\Controllers\Api\Admin\BranchController;
use App\Http\Controllers\Api\Admin\DesignationController;
use App\Http\Controllers\Api\Admin\SiteController;
use App\Http\Controllers\Api\Admin\ShiftController;
use App\Http\Controllers\Api\Admin\LeaveTypeController;
use App\Http\Controllers\Api\Admin\SalaryStructureController;
use App\Http\Controllers\Api\Admin\HolidayController;

use App\Http\Controllers\Api\Admin\TrainingTypeController;

use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\Admin\AttendanceController as AdminAttendanceController;

use App\Http\Controllers\Api\StateController;
use App\Http\Controllers\Api\CityController;

/*
|--------------------------------------------------------------------------
| NEW Mining Workforce Controllers
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    */

    Route::prefix('auth')->group(function () {

        Route::post('login', [AuthController::class, 'login']);

        Route::post('send-otp', [AuthController::class, 'sendOtp']);

        Route::post('verify-otp', [AuthController::class, 'verifyOtp']);

        Route::post('resend-otp', [AuthController::class, 'resendOtp']);
        Route::post('/password/request', [AuthController::class, 'requestPasswordOtp'])->middleware('throttle:5,1'); // 5 requests per minute per IP
        Route::post('/password/reset', [AuthController::class, 'resetPasswordWithOtp'])->middleware('throttle:5,1'); // 5 requests per minute per IP

    });

    /*
    |--------------------------------------------------------------------------
    | Public APIs
    |--------------------------------------------------------------------------
    */

    Route::get('/states', [StateController::class, 'getStates']);

    Route::get('/states/{id}/cities', [CityController::class, 'getCities']);

    /*
    |--------------------------------------------------------------------------
    | Employee Attendance APIs
    |--------------------------------------------------------------------------
    */

    Route::middleware(['auth:sanctum'])
        ->prefix('attendance')
        ->group(function () {

            Route::post('mark-in', [AttendanceController::class, 'markAttendance']);

            Route::post('mark-out', [AttendanceController::class, 'markOutAttendance']);

            Route::post('history', [AttendanceController::class, 'getAttendance']);

            Route::post('status', [AttendanceController::class, 'checkStatus']);

            Route::post('correction', [AttendanceController::class, 'requestCorrection']);
        });

    /*
    |--------------------------------------------------------------------------
    | ADMIN APIs
    |--------------------------------------------------------------------------
    */
    // Route::middleware('auth:sanctum')->get('/auth-check', function () {
    //     return response()->json([
    //         'message' => 'AUTH WORKING',
    //         'user' => auth()->user()
    //     ]);
    // });

    Route::middleware(['auth:sanctum'])->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
        Route::post('/change-password', [AuthController::class, 'changePassword']);

        // ADMIN ONLY
        Route::middleware(['role:super-admin'])->prefix('admin')->group(function () {

            Route::apiResource('employees', EmployeeController::class);

            Route::post('employees/bulk-upload', [EmployeeController::class, 'bulkUpload']);

            Route::patch('employees/{id}/status', [EmployeeController::class, 'toggleStatus']);

            Route::delete('{id}', [EmployeeController::class, 'destroy']);

            Route::apiResource('departments', DepartmentsController::class);

            Route::patch('departments/{id}/status', [DepartmentsController::class, 'toggleStatus']);
            Route::apiResource('designation', DesignationController::class);
            Route::patch('designation/{id}/status', [DesignationController::class, 'toggleStatus']);
            Route::apiResource('sites', SiteController::class);

            Route::patch('sites/{id}/status', [SiteController::class, 'toggleStatus']);
            Route::apiResource('shift', ShiftController::class);

            Route::patch('shift/{id}/status', [ShiftController::class, 'toggleStatus']);
            Route::apiResource('leavetype', LeaveTypeController::class);

            Route::patch('leavetype/{id}/status', [LeaveTypeController::class, 'toggleStatus']);
            Route::apiResource('salarystructure', SalaryStructureController::class);

            Route::patch('salarystructure/{id}/status', [SalaryStructureController::class, 'toggleStatus']);
            Route::apiResource('holiday', HolidayController::class);

            Route::patch('holiday/{id}/status', [HolidayController::class, 'toggleStatus']);
            Route::apiResource('trainingtype', TrainingTypeController::class);

            Route::patch('trainingtype/{id}/status', [TrainingTypeController::class, 'toggleStatus']);
        });

        // NORMAL USER

    });

    Route::middleware(['auth:sanctum', 'role:super-admin'])->prefix('admin')
        ->group(function () {



            /*
            |--------------------------------------------------------------------------
            | Departments
            |--------------------------------------------------------------------------
            */

            Route::prefix('departments')->group(function () {

                Route::get('/', [DepartmentsController::class, 'index']);

                Route::get('{id}', [DepartmentsController::class, 'show']);

                Route::post('/', [DepartmentsController::class, 'store']);

                Route::patch('{id}/status', [DepartmentsController::class, 'toggleStatus']);

                Route::delete('{id}', [DepartmentsController::class, 'destroy']);
            });

            /*
            |--------------------------------------------------------------------------
            | Sites
            |--------------------------------------------------------------------------
            */


            /*
            |--------------------------------------------------------------------------
            | Employees
            |--------------------------------------------------------------------------
            */



            /*
            |--------------------------------------------------------------------------
            | Employee Shift Assignment
            |--------------------------------------------------------------------------
            */


            /*
            |--------------------------------------------------------------------------
            | Existing Vehicle Management Routes
            |--------------------------------------------------------------------------
            */

            // KEEP YOUR EXISTING VEHICLE ROUTES HERE
            // NO CHANGES REQUIRED
        });
});
